package Model.Roles;

/**
 * Enum containing the Roles assignment permissions.
 */
public enum Permission{
    assignDevelopersToBugReport
}
