package Model;

import java.util.ArrayList;
import java.util.List;

public class Comment extends Subject implements Observer<Comment>
{
	private List<Comment> commList = new ArrayList<>();
	
	public String toString()
	{
		return "COMMENT";
	}
	
	public void addComment(Comment comm)
	{
		commList.add(comm);
		comm.addObserver(this);
		notifyObservers(comm);
	}

	@Override
	public void update(Subject s, Object aspect) {
		if(aspect instanceof Comment)
			notifyObservers(aspect);
		
	}
}
