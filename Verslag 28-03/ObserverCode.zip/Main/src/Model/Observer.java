package Model;


public interface Observer<T> {
	
	public void update(Subject s, Object aspect);

}
