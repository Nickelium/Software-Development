package Model;

public class BugReport extends Subject implements Observer<Comment>
{
	private Tag tag;
	private Comment comm;
	
	public void setTag(Tag tag)
	{
		this.tag = tag;
		notifyObservers(tag);
	}
	
	public void setComment(Comment comm)
	{
		this.comm = comm;
		comm.addObserver(this);
		notifyObservers(comm);
	}

	@Override
	public void update(Subject s, Object aspect) {
		if(aspect instanceof Comment)
		notifyObservers(aspect);
		
	}

}
