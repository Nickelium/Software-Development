package Model;


public class Mail 
{
	String content;
	
	public Mail(String str)
	{
		content = str;
		System.out.println(content);
	}
}
