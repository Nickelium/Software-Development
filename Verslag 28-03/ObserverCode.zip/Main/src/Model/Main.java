package Model;

import Model.TagTypes.*;


public class Main 
{
	public static void main(String[] a)
	{
		Mailbox mb = new Mailbox();
		BugReport bug = new BugReport();
		Comment c = new Comment();
		Comment cc = new Comment();
		
		mb.registerComment(bug);
		mb.registerTag(bug);
		mb.registerSpecificTag(bug, new Closed());
		
		//Mailbox mb2 = new Mailbox();
		//mb2.registerComment(bug);
		
		bug.setComment(c);
		bug.setTag(new New());
		bug.setTag(new Closed());
		c.addComment(cc);
		
	
	}
}
