package Model;

import java.util.ArrayList;
import java.util.List;

public class Mailbox 
{
	List<Mail> mails = new ArrayList<>();
	Mailbox() {}
	
	public void registerComment(BugReport bugreport)
	{
		bugreport.addObserver(new ObserverCommment());
	}
	
	public void registerTag(BugReport bugreport)
	{
		bugreport.addObserver(new ObserverTag());
	}
	
	public void registerSpecificTag(BugReport bugreport, Tag tag)
	{
		bugreport.addObserver(new ObserverSpecificTag(tag));
	}

	public void unregister()
	{
		
	}
	
	private class ObserverTag implements Observer<Tag>
	{

		@Override
		public void update(Subject s, Object aspect) 
		{
			if(aspect instanceof Tag)
				mails.add(new Mail("TAG MAIL"));
			
		}
		
	}
	
	private class ObserverSpecificTag implements Observer<Tag>
	{
		private Tag tag;
		
		ObserverSpecificTag(Tag tag)
		{
			this.tag = tag;
		}
		
		@Override
		public void update(Subject s, Object aspect) 
		{
			if(tag.getClass().isInstance(aspect))
				mails.add(new Mail("TAG SPECIFIC MAIL"));
			
		}
		
	}
	
	private class ObserverCommment implements Observer<Comment>
	{

		@Override
		public void update(Subject s, Object aspect)
		{
			if(aspect instanceof Comment)
				mails.add(new Mail("COMMENT MAIL"));
			
		}
		
	}
}
