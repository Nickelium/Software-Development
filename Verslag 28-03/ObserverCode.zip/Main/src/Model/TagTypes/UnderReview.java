package Model.TagTypes;

import java.util.Arrays;

import Model.Tag;

/**
 * Created by Tom on 19/02/16.
 */
public class UnderReview extends Tag {

    /**
     * Default constructor for the underReview tag.
     */
    public UnderReview(){
        this.acceptedTags = Arrays.asList(Resolved.class, Assigned.class, Closed.class);
    }

    @Override
    public String toString() {
        return "UnderReview";
    }

    @Override
    public boolean equals(Object obj) {
        if (obj instanceof UnderReview) return true;
        else return false;
    }
}
