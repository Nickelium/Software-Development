package Model;

public class SubSystem {

}
